﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VRageMath;

namespace IngameScript
{
    public static class Data
    {
        public static Vector3D prevTargetVelocity = Vector3D.Zero;
    }
}
